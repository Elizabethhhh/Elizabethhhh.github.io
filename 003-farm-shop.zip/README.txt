A Pen created at CodePen.io. You can find this one at https://codepen.io/elizabethhhh/pen/jvXyEJ.

 Based on this pin at Pinterest: https://www.pinterest.ph/pin/431430839300874759/